#include <stdio.h>

int main()
{
    printf("Executando execv na thread.\n");
    return 0;
}