/*
Universidade Federal de Itajubá
SRSC02 – Sistemas Operacionais
Gabriel Carneiro Roque Toti Silva - 2023005594
Antony Souza Siqueira - 2022015120
EP05 - Implementação do Sistemas de Arquivos (Exercício 2)
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/* Definição das constantes */
#define TAMANHO_CLUSTER 512
#define OFFSET_DIRETORIO 0
#define NUM_ENTRADAS_DIR 8

/* Estruturas de dados */
typedef struct {
    unsigned short dia;
    unsigned short mes;
    unsigned short ano;
    unsigned short hora;
    unsigned short min;
    unsigned short seg;
} data;

typedef struct {
    char nome[8];
    char extensao[3];
    unsigned short sistema;
    unsigned short hidden;
    unsigned short archieved;
    data criacao;
    data acesso;
    unsigned long int tamanho;
    unsigned long int cluster;
} arquivo;

typedef struct {
    char dados[512];
    unsigned long int prox;
} cluster;

/* Função auxiliar para remover espaços em branco e converter para maiúsculas */
void normalizar_nome(char *dest, const char *src) {
    int i;
    for (i = 0; src[i] && src[i] != '.' && i < 8; i++) {
        dest[i] = toupper(src[i]);
    }
    dest[i] = '\0';
}

void normalizar_extensao(char *dest, const char *src) {
    const char *ext = strchr(src, '.');
    int i = 0;
    
    if (ext) {
        ext++; // Pula o ponto
        for (i = 0; ext[i] && i < 3; i++) {
            dest[i] = toupper(ext[i]);
        }
    }
    dest[i] = '\0';
}

arquivo* buscar_arquivo(FILE* disco, const char* nome_arquivo) {
    arquivo* dir_entry = (arquivo*)malloc(sizeof(arquivo));
    char nome_norm[9], ext_norm[4];
    char nome_entrada[9], ext_entrada[4];
    
    normalizar_nome(nome_norm, nome_arquivo);
    normalizar_extensao(ext_norm, nome_arquivo);

    for (int i = 0; i < NUM_ENTRADAS_DIR; i++) {
        fseek(disco, OFFSET_DIRETORIO + i * sizeof(arquivo), SEEK_SET);
        fread(dir_entry, sizeof(arquivo), 1, disco);

        strncpy(nome_entrada, dir_entry->nome, 8);
        strncpy(ext_entrada, dir_entry->extensao, 3);
        nome_entrada[8] = '\0';
        ext_entrada[3] = '\0';

        if (strncmp(nome_norm, dir_entry->nome, strlen(nome_norm)) == 0 &&
            strncmp(ext_norm, dir_entry->extensao, 3) == 0) {
            return dir_entry;
        }
    }

    free(dir_entry);
    return NULL;
}

void imprimir_conteudo(FILE* disco, arquivo* arq) {
    cluster clust;
    unsigned long int cluster_atual = arq->cluster;
    int num_clusters = 0;
    int bytes_lidos = 0;
    int bytes_desperdicados;

    printf("\nConteudo do arquivo:\n");
    printf("-------------------\n");

    while (cluster_atual != 0 && bytes_lidos < arq->tamanho) {
        fseek(disco, cluster_atual * sizeof(cluster), SEEK_SET);
        fread(&clust, sizeof(cluster), 1, disco);
        
        int bytes_restantes = arq->tamanho - bytes_lidos;
        int bytes_cluster = (bytes_restantes < TAMANHO_CLUSTER) ? bytes_restantes : TAMANHO_CLUSTER;
        
        fwrite(clust.dados, 1, bytes_cluster, stdout);
        
        bytes_lidos += bytes_cluster;
        cluster_atual = clust.prox;
        num_clusters++;
    }

    bytes_desperdicados = TAMANHO_CLUSTER - (arq->tamanho % TAMANHO_CLUSTER);
    if (bytes_desperdicados == TAMANHO_CLUSTER) {
        bytes_desperdicados = 0;
    }

    printf("\n\nEstatisticas:\n");
    printf("-------------\n");
    printf("Sequencia de clusters: ");
    cluster_atual = arq->cluster;
    while (cluster_atual != 0) {
        printf("%lu ", cluster_atual);
        fseek(disco, cluster_atual * sizeof(cluster), SEEK_SET);
        fread(&clust, sizeof(cluster), 1, disco);
        cluster_atual = clust.prox;
    }
    printf("\n");
    printf("Quantidade de clusters: %d\n", num_clusters);
    printf("Tamanho do arquivo: %lu bytes\n", arq->tamanho);
    printf("Bytes desperdicados no ultimo cluster: %d bytes\n", bytes_desperdicados);
}

int main(int argc, char* argv[]) {
    FILE* disco;
    arquivo* arq;
    
    if (argc != 2) {
        printf("Uso: type <nome_arquivo>\n");
        return 1;
    }

    disco = fopen("Disco.dat", "rb");
    if (disco == NULL) {
        printf("Erro ao abrir o arquivo Disco.dat\n");
        return 1;
    }

    arq = buscar_arquivo(disco, argv[1]);
    if (arq == NULL) {
        printf("Arquivo %s nao encontrado\n", argv[1]);
        fclose(disco);
        return 1;
    }

    imprimir_conteudo(disco, arq);

    free(arq);
    fclose(disco);
    return 0;
}